use CITS3200;
delete from Question;
alter table Question auto_increment=1;