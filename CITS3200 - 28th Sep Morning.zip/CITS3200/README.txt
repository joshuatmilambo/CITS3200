HOW TO RUN WEB APP WITH NODE.JS AND NODEMON - WINDOWS

1. Download Node.js and open Node.js command prompt (not Node.js)

2. Navigate to directory of web app
	E.G. cd C:\Users\selfa\Documents\University\CITS3200\webapp

3. Install nodemon
	npm install -g nodemon

4. Run npm install to install dependencies
	npm install

5. Run nodemon to start the web app
	nodemon

6. View web app on localhost:3000


NOTE: Use npm install when adding packages to save them to dependecies.