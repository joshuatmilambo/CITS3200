Created by Sam Fairs (21929393) and Hei Wong (21862296)

To see deployed web application visit: http://cits3403-task-planner.herokuapp.com/

To run web application locally, install dependencies and run nodeom
E.G.
	npm install
	nodemon 

To deploy web application to cloud simply push the git to cloud platform.
E.G. For Heroku:
	git push heroku master

To access remote MongoDB via mongo shell
E.G.
	mongo ds133550.mlab.com:33550/taskplanner -u webApp -p password