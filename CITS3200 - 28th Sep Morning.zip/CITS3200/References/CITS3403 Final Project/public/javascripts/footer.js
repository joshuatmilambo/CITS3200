document.getElementById('modified').innerHTML = ' ' + document.lastModified;
document.getElementById('current').innerHTML = ' ' + Date();


