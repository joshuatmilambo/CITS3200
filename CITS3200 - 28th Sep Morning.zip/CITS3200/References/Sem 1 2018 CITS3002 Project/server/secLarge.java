import java.util.*;
public class secLarge{
		public static int secondLarge(int vectors[], intn){

}

 	public static void main(String[] args){
 		int [] v = {2,1};
	 int n  = v.length;
	int res = secondLarge(v,n);
	System.out.print(res);
 	}
}